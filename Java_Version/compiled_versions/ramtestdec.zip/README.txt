This folder contains the different standalone Java "compiled" versions.

Requiriments:
Java JRE/JDK 8 or later.
Java in your system path (if not included already)
or
direct call to the java runtime on your system.

syntax:
java -jar nameofthejar.jar

examples:
java -jar ramtestdec097.jar
java -jar ramtestdec097.jar -h
java -jar ramtestdec097.jar 70014E7B 70014E3B 0002000C

To check the version:
java -jar ramtestdec097.jar -v
