This folder contains the different standalone Java "compiled" versions.

Requiriments:
Java JRE/JDK 11 or later.
Java in your system path (if not included already)
or
direct call to the java runtime on your system.

syntax:
java -jar nameofthejar.jar

Cheers,
Popopo (aka Lindyhop)

Changelog:
0.93 => compiled to run from Java 11 + aesthetic changes
0.94 => compiled to run from Java 1.8 + aesthetic changes + factoring
0.96b => added graphical representation of the faulty ram map zone afected also added no colors option for terminals that doesn't support ANSI codes. Other minor changes.
0.97c => Added graphical layout of the results. Added some extra information, bug fixes and minor changes.
